#!/system/bin/sh

# M35 Galaxy AI Unlock - KernelSU module
# Applies the user's tested floating_feature.xml changes before Zygote starts.

MODDIR=${0%/*}
SRC=/system/etc/floating_feature.xml
OUT="$MODDIR/floating_feature.xml"
MODEL=SM-S928B
P=SEC_FLOATING_FEATURE_
LOG="$MODDIR/ai_unlock.log"

export PATH=/data/adb/ksu/bin:/data/adb/ap/bin:/data/adb/magisk:/debug_ramdisk:/system/bin:/system/xbin:$PATH

log() {
    echo "[M35 Galaxy AI] $*" >> "$LOG"
}

# Start a fresh log for this boot.
: > "$LOG"
log "Starting module."

if [ ! -r "$SRC" ]; then
    log "ERROR: Cannot read $SRC"
    exit 1
fi

# Copy the original system XML into the module directory. This keeps the
# source persistent across boots while leaving the read-only system partition
# untouched.
if ! cp -f "$SRC" "$OUT"; then
    log "ERROR: Could not copy floating_feature.xml"
    exit 1
fi

if ! grep -q '</SecFloatingFeatureSet>' "$OUT"; then
    log "ERROR: Expected SecFloatingFeatureSet closing tag was not found."
    rm -f "$OUT"
    exit 1
fi

set_tag() {
    TAG="$P$1"
    VALUE="$2"
    sed -i "/<$TAG>/d" "$OUT"
    sed -i "s|</SecFloatingFeatureSet>|<$TAG>$VALUE</$TAG>\n</SecFloatingFeatureSet>|" "$OUT"
}

set_tag COMMON_DISABLE_NATIVE_AI FALSE
set_tag COMMON_SUPPORT_DISABLED_MENU_K05 FALSE
set_tag COMMON_CONFIG_AI_VERSION 20261
set_tag GENAI_SUPPORT_IMAGE_CLIPPER TRUE
set_tag GENAI_SUPPORT_OBJECT_ERASER TRUE
set_tag GENAI_SUPPORT_SMART_SELECT TRUE
set_tag GALLERY_SUPPORT_PHOTO_REMASTER TRUE

sed -i 's|ANIMATION_TYPE>LowEnd<|ANIMATION_TYPE>HighEnd<|g' "$OUT"

chmod 644 "$OUT"
chown 0:0 "$OUT" 2>/dev/null
chcon u:object_r:system_file:s0 "$OUT" 2>/dev/null

# Bind mount in PID 1's mount namespace so Android system processes see it.
NSENTER="$(command -v nsenter 2>/dev/null)"
if [ -z "$NSENTER" ]; then
    log "ERROR: nsenter not found; cannot bind-mount the modified XML."
    exit 1
fi

if ! "$NSENTER" -t 1 -m -- mount -o bind "$OUT" "$SRC"; then
    log "ERROR: Bind mount failed."
    exit 1
fi
log "floating_feature.xml bind mount applied."

# Apply the same model-property spoofing as the tested terminal script.
RESETPROP="$(command -v resetprop 2>/dev/null)"
if [ -z "$RESETPROP" ] && [ -x /data/adb/ksu/bin/resetprop ]; then
    RESETPROP=/data/adb/ksu/bin/resetprop
fi

if [ -z "$RESETPROP" ]; then
    log "ERROR: resetprop not found; model properties were not changed."
else
    for p in \
        ro.product.model \
        ro.product.system.model \
        ro.product.vendor.model \
        ro.product.odm.model \
        ro.product.product.model \
        ro.product.system_ext.model; do
        if "$RESETPROP" -n "$p" "$MODEL"; then
            log "Set $p=$MODEL"
        else
            log "WARNING: Failed to set $p"
        fi
    done
fi

log "Module execution finished."
exit 0
