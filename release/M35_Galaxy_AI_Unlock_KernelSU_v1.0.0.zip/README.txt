M35 Galaxy AI Unlock - KernelSU Module
======================================

Device: Samsung Galaxy M35 5G (SM-M356B / m35x, Exynos 1380)
Tested configuration: One UI 9 / Android 17
Original method tested by developer: Temporary Root + terminal script
Module author: saver420
Telegram support: https://t.me/saver2022

What it does
------------
- Adds/enables the same Galaxy AI floating_feature.xml entries as the
  developer's tested terminal script:
    COMMON_DISABLE_NATIVE_AI = FALSE
    COMMON_SUPPORT_DISABLED_MENU_K05 = FALSE
    COMMON_CONFIG_AI_VERSION = 20261
    GENAI_SUPPORT_IMAGE_CLIPPER = TRUE
    GENAI_SUPPORT_OBJECT_ERASER = TRUE
    GENAI_SUPPORT_SMART_SELECT = TRUE
    GALLERY_SUPPORT_PHOTO_REMASTER = TRUE
- Changes LowEnd animation type to HighEnd when the matching XML entry exists.
- Applies the same SM-S928B model-property spoofing as the original script.
- Uses a systemless bind mount. It does not directly overwrite the original
  /system/etc/floating_feature.xml file.

Installation
------------
1. Install the ZIP in KernelSU Manager > Modules > Install from storage.
2. Reboot using the reboot prompt provided by KernelSU Manager.
3. After boot, check the supported Galaxy AI features.

Disable / remove
---------------
Disable or uninstall the module in KernelSU Manager, then reboot. The bind
mount and module-applied property changes are re-applied only while the module
is enabled. The original system XML is not edited in place.

Important
---------
- Experimental community module. The developer has tested the original
  terminal method on One UI 9 / Android 17; this packaged KernelSU version
  still needs user-side confirmation on the target device.
- Requires KernelSU and the nsenter and resetprop utilities.
- This module deliberately spoofs several ro.product.*.model properties to
  SM-S928B, matching the developer's working script. This may affect device
  identification in apps or services.
- Intended for Samsung Galaxy M35 5G only. Do not flash on other models.
- Keep a way to disable the module from KernelSU Safe Mode if boot behavior
  is abnormal.
